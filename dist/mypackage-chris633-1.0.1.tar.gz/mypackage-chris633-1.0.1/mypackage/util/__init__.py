import flask
def sayhello():
	print("hello")
